package com.cg.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.example.beans.Customer;
import com.cg.example.beans.Merchant;
import com.cg.example.service.AdminService;

@RestController
public class AdminController {
	
	@Autowired
	private AdminService service;

	@RequestMapping(value ="/adminActions/showCustomers" ,  method = RequestMethod.POST)
	public String ListAllCustomers(Model model)
	{
		List<Customer> list=service.findUsers();
		model.addAttribute("list",list);
		return "ListOfCustomers";
		
	}
	
	@RequestMapping(value = "/adminActions/showMerchants",  method = RequestMethod.POST)
	public String ListAllMerchants(Model model) {
		List<Merchant> list=service.findMerchants();
		model.addAttribute("list",list);
		return "ListOfCustomers";
		
	}
	
}
