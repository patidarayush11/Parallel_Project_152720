package com.cg.example.service;

import org.springframework.stereotype.Service;

import com.cg.example.beans.Customer;
@Service
public interface UserService {

	public Customer userSignUp(Customer customer);

	public Customer findUser(Customer customer);

}
