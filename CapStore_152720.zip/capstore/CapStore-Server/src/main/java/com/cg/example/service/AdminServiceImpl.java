package com.cg.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.cg.example.beans.Customer;
import com.cg.example.beans.Merchant;
import com.cg.example.repo.MerchantRepo;
import com.cg.example.repo.UserRepo;

public class AdminServiceImpl implements AdminService {

	@Autowired
	private MerchantRepo merchantRepo;
	
	@Autowired
	private UserRepo userRepo;
	
	@Override
	public List<Customer> findUsers() {
		List<Customer> lst= userRepo.findAll();
		return lst;
	}

	@Override
	public List<Merchant> findMerchants() {
		// TODO Auto-generated method stub
		List<Merchant> merchantList=merchantRepo.findAll();
		
		return merchantList;
	}

}
