package com.cg.example.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.example.beans.Customer;
import com.cg.example.beans.Merchant;

@Service
public interface AdminService {

	public List<Customer> findUsers();
	
	public List<Merchant> findMerchants();
}
