package com.cg.example.controller;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.cg.example.beans.Merchant;

@RestController("/merchant")
public class MerchantController {
	

	@RequestMapping("/signUp")
	public Merchant signUp(@ModelAttribute Merchant merchant)
	{
	RestTemplate send = new RestTemplate();
	
	return send.postForObject("http://localhost:8081/merchantActions/signUp",merchant,Merchant.class);
	}
	
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public Merchant login(@RequestParam int loginId, @RequestParam String password) {
		
		Merchant merchant = new Merchant();
		merchant.setId(loginId);
		merchant.setPassword(password);
		RestTemplate send = new RestTemplate();
		
		return send.postForObject("http://localhost:8081/merchantActions/login",merchant,Merchant.class);	
	}
	
	
	
	
	
	
	
}
