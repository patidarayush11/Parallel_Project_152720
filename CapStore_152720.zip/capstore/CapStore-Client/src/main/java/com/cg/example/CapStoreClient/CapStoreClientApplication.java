package com.cg.example.CapStoreClient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CapStoreClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(CapStoreClientApplication.class, args);
	}
}
